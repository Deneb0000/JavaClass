package TennisScorer;

public class ScoreBoard {
	public void displayScore(Player player1, Player player2, int currentSet) {
		System.out.println("------------------------------------------------------------------------");
		System.out.printf("%-10s\t%-7s\t%-5s\t%-4s\n", "이름", "Point", "Game", "Set");
		System.out.println("------------------------------------------------------------------------");
		System.out.printf("%-10s\t%-7s\t%-5d\t%-4d\n", player1.getName()
				                                     , pointToString(player1.getCurrentGamePoints())
				                                     , player1.getGamesWonInCurrentSet(currentSet)
				                                     , player1.getSetsWon());
		System.out.println("------------------------------------------------------------------------");
		System.out.printf("%-10s\t%-7s\t%-5d\t%-4d\n", player2.getName()
				                                     , pointToString(player2.getCurrentGamePoints())
				                                     , player2.getGamesWonInCurrentSet(currentSet)
				                                     , player2.getSetsWon());
		System.out.println("------------------------------------------------------------------------");
	}

	private String pointToString(int points) {
		switch (points) {
		case 0: return "0";
		case 1: return "15";
		case 2: return "30";
		case 3: return "40";
		default: return "AD"; // Advantage
		}
	}
}
