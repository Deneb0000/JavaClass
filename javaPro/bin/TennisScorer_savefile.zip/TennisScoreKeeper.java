package TennisScorer;

public class TennisScoreKeeper {
	
    private int numSets; // set수 입력
    private Player player1;
    private Player player2;
    private Game game; // game 변수
    private Set set; // 세트 변수
    private ScoreBoard scoreBoard; // 점수 출력 class
  
    public TennisScoreKeeper(int numSets, String player1Name, String player2Name) {
    //입력 받은 세트수, player1, player2 넘겨주기	
        this.numSets = numSets;
        this.player1 = new Player(player1Name, numSets);
        this.player2 = new Player(player2Name, numSets);
        this.set = new Set(player1, player2, 0);
        this.game = new Game(player1, player2, set.getCurrentSet());
        this.scoreBoard = new ScoreBoard();
    }

    // point 승리 check
    public void pointWinner(int p) {
        game.pointWinner(p);
        set.checkSetWinner();

        // 세트 update -> game class에 반영
        game.setCurrentSet(set.getCurrentSet());

        if (player1.getSetsWon() > numSets / 2 || player2.getSetsWon() > numSets / 2) {
            scoreBoard.displayScore(player1, player2, set.getCurrentSet());
            System.out.println("WINNER! : " + (player1.getSetsWon() > player2.getSetsWon() ? player1.getName() : player2.getName()));
            System.exit(0);
        }

        scoreBoard.displayScore(player1, player2, set.getCurrentSet());
    } 
}

