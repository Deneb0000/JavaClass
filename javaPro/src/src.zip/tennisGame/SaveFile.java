package tennisGame;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class SaveFile {
	String fileName = ".\\src\\tennisGame\\SaveFile.txt";
	File file = new File("SaveFile.txt");
	
	ScoreBoard sb = new ScoreBoard();
	Player pl = new Player();
	

	public SaveFile(String fileName) {
		this.fileName = fileName;
	}

	public void saveScorePalyer(String name, int scoreBoardSet/*임의의세트*/, int scoreBoardGame/*임의의게임*/, int scoreBoardScore/*임의의점수*/) {
        try (FileWriter writer = new FileWriter(fileName, true)) {
//             이름과 점수를 파일에 저장
         	Player pl = new Player();
			String info1 = String.format("%s - %d : %d : %d\n",pl.name[0],scoreBoardSet,scoreBoardGame,scoreBoardScore);
			String info2 = String.format("%s - %d : %d : %d\n",pl.name[1],scoreBoardSet,scoreBoardGame,scoreBoardScore);
			writer.write(info1);
			writer.write(info2);
			writer.flush();
            System.out.println(info1);
            System.out.println(info2);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// 사용 예시
		Scanner scanner = new Scanner(System.in);

		Player pr = new Player();
    	ScoreBoard sb = new ScoreBoard();
		SaveFile saveFile = new SaveFile(".\\src\\tennisGame\\SaveFile.txt");
//    	saveFile.saveScorePalyer(플레이어, 세트, 게임, 점수);
		saveFile.saveScorePalyer(pr.name[1], 0, 1, 15);
		saveFile.saveScorePalyer(pr.name[2], 1, 3, 40);

		// Scanner 닫기
		scanner.close();
	}
}