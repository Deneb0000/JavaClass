//package tennisGame;
//
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.util.Scanner;
//
//public class Main {
//
//	public static void main(String[] args) {
//
//		// 3세트 or 5세트
//		// 플레이어 2명
//		// 이름을 입력 받을 것이고
//		// 그러려면 플레이어를 생성하는 객체를 만들어야지
//
//		Player p1 = new Player();
//		p1.GameStart();
//
//		// 게임 시작
//		// 점수가 랜덤으로 오르는 테니스 점수판 출력되게
//
//		ScoreBoard sb = new ScoreBoard();
//
//
//
//		// 게임 종료 안내
//		System.out.println("경기가 종료되었습니다.");
//
//	}
//}
package tennisGame;

import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) {
        ScoreBoard scoreBoard = new ScoreBoard();
        FileOutput fileOutput = new FileOutput();

        try {
            // 파일 출력 시작
            fileOutput.startFileOutput(".\\src\\tennisGame\\SaveFile.txt");

            scoreBoard.createScoreBoard();

            // 선수 이름 설정
            String[] playerNames = {"Player 1", "Player 2"};
            scoreBoard.setScoreBoardName(playerNames);

            // 포인트 점수 업데이트 및 출력 예시
            scoreBoard.printScore("15", "0");
            scoreBoard.printScore("30", "15");
            scoreBoard.printScore("40", "30");
            scoreBoard.printScore("Adv", "40");

            // 게임 점수 업데이트 및 출력 예시
            scoreBoard.printGame(0, "1");
            scoreBoard.printGame(1, "1");
            scoreBoard.printGame(0, "2");
            scoreBoard.printGame(0, "3");

            // 세트 점수 업데이트 및 출력 예시
            scoreBoard.printSet(0, "1");
            scoreBoard.printSet(1, "0");

            // 파일 출력 종료
            fileOutput.stopFileOutput();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}

