package tennisGameC;

import java.io.FileWriter;
import java.io.IOException;

import tennisGame.FileOutput;
import tennisGame.Player;
import tennisGame.ScoreBoard;

public class GG {
	// 파일 출력 시작
    fileOutput.startFileOutput(".\\src\\tennisGame\\SaveFile.txt");
   scoreBoard.createScoreBoard();
	
	public void saveScorePalyer(String name, int scoreBoardSet/*임의의세트*/, int scoreBoardGame/*임의의게임*/, int scoreBoardScore/*임의의점수*/) {
		ScoreBoard scoreBoard = new ScoreBoard();
        FileOutput fileOutput = new FileOutput();
		
		try (FileWriter writer = new FileWriter(fileName, true)) {
//             이름과 점수를 파일에 저장
         	Player pl = new Player();
			String info1 = String.format("%s - %d : %d : %d\n",pl.name[0],scoreBoardSet,scoreBoardGame,scoreBoardScore);
			String info2 = String.format("%s - %d : %d : %d\n",pl.name[1],scoreBoardSet,scoreBoardGame,scoreBoardScore);
			writer.write(info1);
			writer.write(info2);
			writer.flush();
            System.out.println(info1);
            System.out.println(info2);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

